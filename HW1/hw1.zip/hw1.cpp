//-----------------------------------------------------------------------
// File : hw1.cpp
//
// Programmer: Jack McGowan
//
// Program #: hw1
//
// Due Date: 2/10/22
//
// Course: EGRE 347, Spring 2022
//
// Pledge: I have neither given nor received unauthorized aid on this program.
//
// Description: Program that maintains and allows manipulation of a linked list of students with their grade, year, and major
//
//-----------------------------------------------------------------------

using namespace std;

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

#include "hw1.h"

void write(fstream& out_file, struct student *list);
void count_majors(struct student *list, int *ee_cnt, int * cpe_cnt, int *mne_cnt, int* cls_cnt, int *cs_cnt);
void count_years(struct student *list, int *fr_cnt, int * so_cnt, int *jr_cnt, int* sr_cnt);
void add_to_head(struct student **list, string last_name, string first_name, string major, string year, float grade);
int menu();
void print(struct student *list);
int removeStudent(struct student* list, string lastName, string firstName);

extern const int MAX_LENGTH;
extern const int MAX_CHAR;
extern const int MAJ;
extern const int CLASS;

int main(int argc, char *argv[])
{
	
	string helpString = "/?";
	
	if (argc == 1 || argv[1] == helpString) {
		cout << "Program to maintain a list of students in a class using a linked list." << endl << endl;
		cout << "Usage: prog1 [input_file_name]" << endl;
		return 0;
	}

	fstream infile;
	fstream outfile;
	string infilename = argv[1];
	string outfilename;

	string last_name_buffer;
	string first_name_buffer;
	string major_temp;
	string year_temp;
	float grade_temp;
	int number, op;
	int fr_count, so_count, jr_count, sr_count;
	int ee_count, cpe_count, mne_count, cls_count, cs_count;

	struct student *head = NULL;
	struct student *current;

	infile.open(infilename, fstream::in);
	
	if(!infile.is_open()) {
		cout << "ERROR: file " << infilename << " can not be opened!\n";
		cout << "Usage: prog1 [input_file_name]" << endl;
		return 0;
	}
	cout << "Program to manipulate a linked list of students\n";
	
	outfilename = infilename.substr(0, infilename.find("."));
	outfilename += "_out.txt";
	outfile.open(outfilename, fstream::out);

	if(!outfile.is_open()) {
		cout << "ERROR: file " << outfilename << " can not be opened!\n";
		exit(-1);
	}

	while(!infile.eof()) {
		infile >> last_name_buffer >> first_name_buffer >> major_temp >> year_temp >> grade_temp;
		add_to_head(&head,last_name_buffer, first_name_buffer, major_temp, year_temp, grade_temp);
	}

	op = 1;
	while(op) {	// check to see if buffer is "done" - if so exit loop
		op = menu();
		switch (op) {
			case 0:
				break;
			case 1:
				print(head);
				break;
			case 2:
				cout << "Enter new student's last name ?";
				cin >> last_name_buffer;
				cout << "Enter new student's first name ?";
				cin >> first_name_buffer;
				cout << "Enter new student's major (EE, CPE, MNE, CSE, CS) ?";
				cin >> major_temp;
				cout << "Enter new student's year (fr, so, jr, sr)?";
				cin >> year_temp;
				cout << "Enter new student's grade ?";
				cin >> grade_temp;
				add_to_head(&head, last_name_buffer, first_name_buffer, major_temp, year_temp, grade_temp);
				break;
			case 3: 
				cout << "Enter student's last name ?";
				cin >> last_name_buffer;
				cout << "Enter student's first name ?";
				cin >> first_name_buffer;
				if (!removeStudent(head, last_name_buffer, first_name_buffer)) {
					cout << "Student " << last_name_buffer << ", " << first_name_buffer << " not found!" << endl;
				}
				break;
			case 4:
				grade_temp = 0.0;
				number = 0;
				for(current = head; current != NULL; current = current->next) {
					grade_temp += current->grade;
					number++;
				}
				grade_temp /= number;
				cout << "The class has " << number << " students and the class grade average is " << fixed << setprecision(2) << grade_temp << endl;
				break;
			case 5:
				count_years(head, &fr_count, &so_count, &jr_count, &sr_count);
				cout << "The class has the following class distributions:\n";
				cout << "\t\tSeniors:\t" << sr_count << "\n";
				cout << "\t\tJuniors:\t" << jr_count << "\n";
				cout << "\t\tSophomores:\t" << so_count << "\n";
				cout << "\t\tFreshmen:\t" << fr_count << "\n";
				break;
			case 6:
				count_majors(head, &ee_count, &cpe_count, &mne_count, &cls_count, &cs_count);
				cout << "The class has the following major distributions:\n";
				cout << "\t\tEE:\t" << ee_count << "\n";
				cout << "\t\tCPE:\t" << cpe_count << "\n";
				cout << "\t\tMNE:\t" << mne_count << "\n";
				cout << "\t\tCSE:\t" << cls_count << "\n";
				cout << "\t\tCS:\t" << cs_count << "\n";
				break;
			default:
				cout << op << " is not a valid choice!\n";
				break;

		}	// end switch

	}	// end while

	cout << "Writing output file " << outfilename << "\n";
	// write output file
	write(outfile, head);

	infile.close();
	outfile.close();

	return 0;
}		/* end main */