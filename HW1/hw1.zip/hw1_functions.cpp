//-----------------------------------------------------------------------
// File : hw1.cpp
//
// Programmer: Jack McGowan
//
// Program #: hw1
//
// Due Date: 2/10/22
//
// Course: EGRE 347, Spring 2022
//
// Pledge: I have neither given nor received unauthorized aid on this program.
//
// Description: Program that maintains and allows manipulation of a linked list of students with their grade, year, and major
//
//-----------------------------------------------------------------------

using namespace std;

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

#include "hw1.h"

extern const int MAX_LENGTH;
extern const int MAX_CHAR;
extern const int MAJ;
extern const int CLASS;

void write(fstream& out_file, struct student *list) {

	struct student *current;

	//print the list again
	for(current=list;current!=NULL;current=current->next) 
		out_file << current->last_name << "\t" << current->first_name << "\t" << current->major << "\t" << current->year << "\t" << fixed << setprecision(2) << current->grade << "\n";
}		/* end write */

void add_to_head(struct student **list, string last_name, string first_name, string major, string year, float grade)
{
	struct student *current;

	if(*list == NULL) {
		*list = new(nothrow) struct student;
		(*list)->last_name = last_name;
		(*list)->first_name = first_name;
		(*list)->major = major;
		(*list)->year = year;
		(*list)->grade = grade;
		(*list)->next = NULL;
	}
	else {
		current = new(nothrow) struct student;
		current->last_name = last_name;
		current->first_name = first_name;
		current->major = major;
		current->year = year;
		current->grade = grade;
		current->next = *list;
		*list = current;
	}
}	// end add_to_head

void count_majors(struct student *list, int *ee_cnt, int * cpe_cnt, int *mne_cnt, int* cls_cnt, int *cs_cnt)
{
	struct student *current;

	*ee_cnt = 0;
	*cpe_cnt = 0;
	*mne_cnt = 0;
	*cls_cnt = 0;
	*cs_cnt = 0;

	for(current = list; current != NULL; current = current->next) {
		if(current->major == "ee" || current->major == "EE")
			(*ee_cnt)++;
		if(current->major == "cpe" || current->major == "CPE")
			(*cpe_cnt)++;
		if(current->major ==  "mne" || current->major == "MNE")
			(*mne_cnt)++;
		if(current->major == "cse" || current->major == "CSE")
			(*cls_cnt)++;
		if(current->major == "cs" || current->major == "CS")
			(*cs_cnt)++;
	}

}

void count_years(struct student *list, int *fr_cnt, int * so_cnt, int *jr_cnt, int* sr_cnt)
{
	struct student *current;

	*fr_cnt = 0;
	*so_cnt = 0;
	*jr_cnt = 0;
	*sr_cnt = 0;

	for(current = list; current != NULL; current = current->next) {
		if(current->year == "fr" || current->year == "FR")
			(*fr_cnt)++;
		if(current->year == "so" || current->year == "SO")
			(*so_cnt)++;
		if(current->year == "jr" || current->year == "JR")
			(*jr_cnt)++;
		if(current->year == "sr" || current->year == "SR")
			(*sr_cnt)++;
	}

}

int menu()
{
	int choice;

	cout << "\nEnter option:\n";
	cout << "\t(0) Write output file and exit\n";
	cout << "\t(1) Print the list\n";
	cout << "\t(2) Add new student at the head of the list" << endl;
	cout << "\t(3) Remove student from the list" << endl;
	cout << "\t(4) Calculate and display the number of students in the class \n";
	cout << "\t\tand the average grade\n";
	cout << "\t(5) Count the number of students in each year in the class \n";
	cout << "\t(6) Count the number of students in each major in the class \n";
	cout << "\t\tChoice ?";

	cin >> choice;
	fflush(stdout);
	cout << "\n";
	return(choice);
}

void print(struct student *list) {

	struct student *current;

	//print the list again
	cout << "Member List\n";
	cout << "Last name\tFirst name\tMajor\tYear\tGrade\n";
	cout << "---------------------------------------------------------\n";
	for(current=list;current!=NULL;current=current->next) 
		cout << current->last_name << "\t\t" << current->first_name << "\t\t" << current->major << "\t" << current->year << "\t" << fixed << setprecision(2) << current->grade << "\n";

}		/* end print */

// int removeStudent (struct student* list, string lastName, string firstName)
// Summary of the removeStudent function:
//
//		The removeStudent function searches the list for a given first and last name and removes them from the list
//
//	Parameters: 	list: First element of the linked list
//					lastName: String with last name of the student to be removed
//					firstName: String with first name of the student to be removed
//
//	Return Value: 	Returns 1 if the student is found and 0 if the student is not found. The value is used to determine if user needs to be told if the suer was not found
//
// Description:
//
//		This function traverses a singly linked list to try to find a particular student to remove from the list

int removeStudent(struct student* list, string lastName, string firstName) {
		struct student* current = list;
		struct student* prev = NULL;
		
		while (current != NULL) {
			if (current->last_name == lastName && current->first_name == firstName) {
				if (current != list) {
					prev->next = current->next;
				} else {
					list = current->next;
				}
				delete(current);
				return 1;
			}
			prev = current;
			current = current->next;
		}
		return 0;
}
