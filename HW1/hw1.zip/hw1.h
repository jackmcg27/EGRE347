//-----------------------------------------------------------------------
// File : hw1.cpp
//
// Programmer: Jack McGowan
//
// Program #: hw1
//
// Due Date: 2/10/22
//
// Course: EGRE 347, Spring 2022
//
// Pledge: I have neither given nor received unauthorized aid on this program.
//
// Description: Program that maintains and allows manipulation of a linked list of students with their grade, year, and major
//
//-----------------------------------------------------------------------

const int MAX_LENGTH = 64;
const int MAX_CHAR = 256;
const int MAJ = 10;
const int CLASS = 10;

struct student {
	string last_name;
	string first_name;
	string major;
	string year;
	float grade;
	struct student *next;
};